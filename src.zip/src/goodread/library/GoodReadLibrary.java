package goodread.library;

public class GoodReadLibrary {

    public static void main(String[] args) {
        MenuPage mp = new MenuPage();
        mp.pack();
        mp.setLocationRelativeTo(null);
        mp.show();
    }
    
}
